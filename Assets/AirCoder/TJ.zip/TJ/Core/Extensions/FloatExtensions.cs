namespace AirCoder.TJ.Core.Extensions
{
    public static class FloatExtensions
    {
        public static float TweenTo(this float from, float to, float duration)
        {
            return 0f;
        }
    }
}